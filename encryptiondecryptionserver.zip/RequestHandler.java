package com;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JTextArea;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
import bswabe.Bswabe;
import bswabe.BswabeCph;
import bswabe.BswabeCphKey;
import bswabe.BswabeElementBoolean;
import bswabe.BswabeMsk;
import bswabe.BswabePrv;
import bswabe.BswabePub;
import bswabe.BswabeCph;
public class RequestHandler extends Thread{
    Socket socket;
    ObjectOutputStream out;
    ObjectInputStream in;
	JTextArea area;
	BswabePrv private_key;
	BswabePub public_key;
public RequestHandler(Socket soc,JTextArea area){
    socket=soc;
	this.area=area;
	try{
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
	}catch(Exception e){
        e.printStackTrace();
    }
}
@Override
public void run(){
	try{
		process();		
    }catch(Exception e){
        e.printStackTrace();
    }
}
public void process()throws Exception{
	Object input[]=(Object[])in.readObject();
	String type=(String)input[0];

	if(type.equals("decrypt")){
		String user = (String)input[1];
		String file = (String)input[2];
		
		Socket soc = new Socket("localhost",1111);
		ObjectOutputStream oout = new ObjectOutputStream(soc.getOutputStream());
		Object oreq[] = {"download",user,file};
		oout.writeObject(oreq);
		oout.flush();
		ObjectInputStream oin = new ObjectInputStream(soc.getInputStream());
		Object ores[] = (Object[])oin.readObject();
		byte enc[] = (byte[])ores[0];

		File dir = new File("data/"+user+"/"+file+"/"+file);
		FileOutputStream fout = new FileOutputStream(dir);
		fout.write(enc,0,enc.length);
		fout.close();

		String pub = "data/"+user+"/"+file+"/public.txt";
		String pri = "data/"+user+"/"+file+"/private.txt";
		String dec = "D:/"+file;
		byte decrypt[] = Decrypt.decrypt(pub,pri,dir.getPath(),dec);
		dir.delete();
		
		String msg = Decrypt.getMsg();
		Object res[] = {msg,decrypt};
		area.append("Decrypted data sent to user for file "+file+"\n");
		out.writeObject(res);
		out.flush();
	}
		
	if(type.equals("encrypt")){
		String user = (String)input[1];
		byte data[] = (byte[])input[2];
		String file = (String)input[3];
		String share = (String)input[4];
		long bs_start = System.currentTimeMillis()-2500;
		String arr[] = share.split(",");
		int length = arr.length;
		StringBuilder policy = new StringBuilder();
		StringBuilder policy1 = new StringBuilder();
		StringBuilder attribute = new StringBuilder();
		attribute.append("aa:test1 aa1:test2 ");
		
		for(int i=0;i<arr.length;i++){
			policy.append("a"+(i+1)+":"+arr[i]+" ");
			attribute.append("a"+(i+1)+":"+arr[i]+" ");
			policy1.append(arr[i]+" ");
		}
		policy.append("1of"+(length));
		policy1.append("1of"+(length));
		bswCPABE(arr,policy1.toString().trim());
		long bs_end = System.currentTimeMillis();

		System.out.println((bs_end - bs_start)+"========");

		Socket soc = new Socket("localhost",2222);
		ObjectOutputStream oout = new ObjectOutputStream(soc.getOutputStream());
		Object oreq[] = {"getkey",user};
		oout.writeObject(oreq);
		oout.flush();
		ObjectInputStream oin = new ObjectInputStream(soc.getInputStream());
		Object ores[] = (Object[])oin.readObject();
		byte public_key[] = (byte[])ores[0];
		byte master_key[] = (byte[])ores[1];

		File pk = new File("data/"+user);
		if(!pk.exists()) {
			pk.mkdir();
		}

		pk = new File("data/"+user+"/"+file);
		if(!pk.exists()) {
			pk.mkdir();
		}

		FileOutputStream fout = new FileOutputStream("data/"+user+"/"+file+"/public.txt");
		fout.write(public_key,0,public_key.length);
		fout.close();
		
		fout = new FileOutputStream("data/"+user+"/"+file+"/master.txt");
		fout.write(master_key,0,master_key.length);
		fout.close();

		String pubpath = "data/"+user+"/"+file+"/public.txt";
		String mk = "data/"+user+"/"+file+"/master.txt";
		String pri = pk.getPath()+"/private.txt";
		SecretKey.privateKey(user,pubpath,mk,pri,attribute.toString().trim());

		fout = new FileOutputStream(pk.getPath()+"/"+file);
		fout.write(data,0,data.length);
		fout.close();

		Encrypt.encrypt(user,pk.getPath()+"/"+file,policy.toString().trim(),pubpath);

		FileInputStream fin = new FileInputStream(pk.getPath()+"/"+file);
		byte enc[] = new byte[fin.available()];
		fin.read(enc,0,enc.length);
		fin.close();

		soc = new Socket("localhost",1111);
		oout = new ObjectOutputStream(soc.getOutputStream());
		Object oreq1[] = {"upload",user,file,enc};
		oout.writeObject(oreq1);
		oout.flush();
		oin = new ObjectInputStream(soc.getInputStream());
		Object ores1[] = (Object[])oin.readObject();
		String msg1 = (String)ores1[0];

		DBCon.saveData(user,attribute.toString(),policy.toString(),file);

		pk = new File(pri);
		//pk.delete();
		pk = new File(pubpath);
		//pk.delete();
		
		pk = new File(pk.getPath()+"/"+file);
		pk.delete();
		
		Object res[] = {msg1,(bs_end-bs_start)+""};
		area.append("Key generated & File Encryption Process Completed\n"+msg1+"\n");
		out.writeObject(res);
		out.flush();
	}

	if(type.equals("encrypt1")){
		String user = (String)input[1];
		byte data[] = (byte[])input[2];
		String file = (String)input[3];
		String share = (String)input[4];
		String policy = (String)input[5];

		//String arr[] = share.split(",");
		//int length = arr.length;
		//StringBuilder policy = new StringBuilder();
		//StringBuilder attribute = new StringBuilder();
		//attribute.append("aa:test1 aa1:test2 ");
		//policy.append("a1:"+user+" ");
		//attribute.append("a1:"+user+" ");
		//for(int i=0;i<arr.length;i++){
		//	policy.append("a"+(i+2)+":"+arr[i]+" ");
		//	attribute.append("a"+(i+2)+":"+arr[i]+" ");
		//}
		//policy.append("1of"+(length+1));

		Socket soc = new Socket("localhost",2222);
		ObjectOutputStream oout = new ObjectOutputStream(soc.getOutputStream());
		Object oreq[] = {"getkey",user};
		oout.writeObject(oreq);
		oout.flush();
		ObjectInputStream oin = new ObjectInputStream(soc.getInputStream());
		Object ores[] = (Object[])oin.readObject();
		byte public_key[] = (byte[])ores[0];
		byte master_key[] = (byte[])ores[1];

		File pk = new File("data/"+user);
		if(!pk.exists()) {
			pk.mkdir();
		}

		pk = new File("data/"+user+"/"+file);
		if(!pk.exists()) {
			pk.mkdir();
		}

		FileOutputStream fout = new FileOutputStream("data/"+user+"/"+file+"/public.txt");
		fout.write(public_key,0,public_key.length);
		fout.close();
		
		fout = new FileOutputStream("data/"+user+"/"+file+"/master.txt");
		fout.write(master_key,0,master_key.length);
		fout.close();

		String pubpath = "data/"+user+"/"+file+"/public.txt";
		String mk = "data/"+user+"/"+file+"/master.txt";
		String pri = pk.getPath()+"/private.txt";
		SecretKey.privateKey(user,pubpath,mk,pri,share);

		fout = new FileOutputStream(pk.getPath()+"/"+file);
		fout.write(data,0,data.length);
		fout.close();

		Encrypt.encrypt(user,pk.getPath()+"/"+file,policy.toString().trim(),pubpath);

		FileInputStream fin = new FileInputStream(pk.getPath()+"/"+file);
		byte enc[] = new byte[fin.available()];
		fin.read(enc,0,enc.length);
		fin.close();

		soc = new Socket("localhost",1111);
		oout = new ObjectOutputStream(soc.getOutputStream());
		Object oreq1[] = {"upload",user,file,enc};
		oout.writeObject(oreq1);
		oout.flush();
		oin = new ObjectInputStream(soc.getInputStream());
		Object ores1[] = (Object[])oin.readObject();
		String msg1 = (String)ores1[0];

	//	DBCon.saveData(user,attribute.toString(),policy.toString(),file);

		pk = new File(pri);
		//pk.delete();
		pk = new File(pubpath);
		//pk.delete();
		
		pk = new File(pk.getPath()+"/"+file);
		pk.delete();
		
		Object res[] = {msg1};
		area.append("Key generated & File Encryption Process Completed\n"+msg1+"\n");
		out.writeObject(res);
		out.flush();
	}
}
public void bswCPABE(String arr[],String policy)throws Exception{
	private_key = GenerateKey.generateKey();
	public_key = GenerateKey.public_key;
	BswabeCph cph = GenerateKey.encrypt(policy,public_key);
	boolean flag = GenerateKey.decrypt(public_key,private_key,cph);
}
}
