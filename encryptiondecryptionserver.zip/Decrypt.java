package com;
import cpabe.Cpabe;
import java.io.File;
import java.io.FileInputStream;
public class Decrypt {
	static String msg;
public static String getMsg(){
	return msg;
}
public static byte[] decrypt(String public_key,String private_key,String enc,String dec_path) {
	byte b[] = null;
	try{
		File dec = new File(dec_path);
		Cpabe test = new Cpabe();
		test.dec(public_key,private_key,enc,dec.getPath());
		FileInputStream fin = new FileInputStream(dec);
		b = new byte[fin.available()];
		fin.read(b,0,b.length);
		fin.close();
		dec.delete();
		msg = "success";
	}catch(Exception e){
		e.printStackTrace();
		b = "error".getBytes();
		msg = "error";
	}
	return b;
}
}
