package com;
public class ServerThread extends Thread{
	EncryptionDecryptionServer server;
public ServerThread(EncryptionDecryptionServer server){
	this.server=server;
	start();
}
public void run(){
	server.start();
}
}