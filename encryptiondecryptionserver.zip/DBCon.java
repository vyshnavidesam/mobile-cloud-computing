package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.sql.Statement;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
public class DBCon{
    private static Connection con;
	static String check = "none";
	
public static Connection getCon()throws Exception {
	try{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/LDSS","root","root");
    }catch(Exception e){
		e.printStackTrace();
	}
	return con;
}

public static String saveData(String user,String attributes,String policy,String file)throws Exception{
    String msg="Error in registration";
    String group = "none";
	con = getCon();
	PreparedStatement stat=con.prepareStatement("insert into share values(?,?,?,?)");
	stat.setString(1,user);
	stat.setString(2,attributes);
	stat.setString(3,policy);
	stat.setString(4,file);
	int i=stat.executeUpdate();
	if(i > 0){
		msg = "success";
	}
    return msg;
}



}
