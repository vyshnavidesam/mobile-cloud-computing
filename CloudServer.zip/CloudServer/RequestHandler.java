package com;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JTextArea;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
public class RequestHandler extends Thread{
    Socket socket;
    ObjectOutputStream out;
    ObjectInputStream in;
	JTextArea area;
public RequestHandler(Socket soc,JTextArea area){
    socket=soc;
	this.area=area;
	try{
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
	}catch(Exception e){
        e.printStackTrace();
    }
}
@Override
public void run(){
	try{
		process();		
    }catch(Exception e){
        e.printStackTrace();
    }
}
public void process()throws Exception{
	Object input[]=(Object[])in.readObject();
	String type=(String)input[0];
	if(type.equals("register")){
		String user = (String)input[1];
		String pass = (String)input[2];
		String contact = (String)input[3];
		String address = (String)input[4];
		String email = (String)input[5];
		String arr[] = {user,pass,contact,address,email};
		String msg = DBCon.register(arr);
		if(msg.equals("success")){
			File file = new File("users/"+user);
			file.mkdir();
			Object res[] = {msg};
			area.append(user+" registered at cloud server\n");
			out.writeObject(res);
			out.flush();
		}else{
			Object res[] = {msg};
			area.append(msg+"\n");
			out.writeObject(res);
			out.flush();
		}
	}
	if(type.equals("login")){
		String user = (String)input[1];
		String pass = (String)input[2];
		String arr[] = {user,pass};
		String msg = DBCon.userLogin(arr);
		if(!msg.equals("invalid login")){
			Object res[] = {msg};
			area.append(user+" login to "+msg+"\n");
			out.writeObject(res);
			out.flush();
		}else{
			Object res[] = {"invalid login"};
			out.writeObject(res);
			out.flush();
		}
	}

	if(type.equals("upload")){
		String user = (String)input[1];
		String file = (String)input[2];
		byte enc[] = (byte[])input[3];

		FileOutputStream fout = new FileOutputStream("users/"+user+"/"+file);
		fout.write(enc,0,enc.length);
		fout.close();
			Upload up = new Upload(user,new File("users/"+user+"/"+file));
		up.join();
		Object res[] = {"success",file+" saved at cloud server"};
		area.append(file+" saved at cloud server\n");
		out.writeObject(res);
		out.flush();
	}

	if(type.equals("download")){
		String user = (String)input[1];
		String file = (String)input[2];
		
		FileInputStream fin = new FileInputStream("users/"+user+"/"+file);
		byte enc[] = new byte[fin.available()];
		fin.read(enc,0,enc.length);
		fin.close();
			
		Object res[] = {enc};
		area.append(file+" data in the cloud is sent to user from owner:"+user+" \n");
		out.writeObject(res);
		out.flush();
	}
}
}
