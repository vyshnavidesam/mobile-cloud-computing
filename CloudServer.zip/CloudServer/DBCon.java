package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.sql.Statement;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
public class DBCon{
    private static Connection con;
	static String check = "none";
	
public static Connection getCon()throws Exception {
	try{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/LDSS","root","root");
    }catch(Exception e){
		e.printStackTrace();
	}
	return con;
}

public static String register(String[] input)throws Exception{
    String msg="Error in registration";
    con = getCon();
	Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select username from users where username='"+input[0]+"'");
    if(rs.next()){
        msg = "Username already exist";
    }else{
		PreparedStatement stat=con.prepareStatement("insert into users values(?,?,?,?,?)");
		stat.setString(1,input[0]);
		stat.setString(2,input[1]);
		stat.setString(3,input[2]);
		stat.setString(4,input[3]);
		stat.setString(5,input[4]);
		int i=stat.executeUpdate();
		if(i > 0){
			msg = "success";
		}
    }
    return msg;
}

public static String shareDetails(String owner,String csp,String tag,String file,String policy)throws Exception{
    String msg="Error in registration";
	String refrence = "none";
	check = "none";
    con = getCon();
	Statement stmt=con.createStatement();
    ResultSet rs = stmt.executeQuery("select csp_name,owner_name,file_name,share_att from share where filetag='"+tag+"'");
    if(rs.next()){
        refrence = rs.getString(1)+","+rs.getString(2)+","+rs.getString(3);
		check = rs.getString(4);
    }
	PreparedStatement stat=con.prepareStatement("insert into share values(?,?,?,?,?,?)");
	stat.setString(1,owner);
	stat.setString(2,csp);
	stat.setString(3,policy);
	stat.setString(4,file);
	stat.setString(5,tag);
	stat.setString(6,refrence);
	int i=stat.executeUpdate();
	if(i > 0)
		msg = "success";
	return refrence;
}
public static String userLogin(String input[])throws Exception{
    String msg="invalid login";
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select username from users where username='"+input[0]+"' and password='"+input[1]+"'");
    if(rs.next()){
	    msg = rs.getString(1);
    }
	rs.close();stmt.close();
    return msg;
}

}
