package com;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.auth.BasicAWSCredentials;
public class Upload extends Thread{
	String user;
	String msg="fail";
	File file;
public String getMessage(){
	return msg;
}
public Upload(String user,File file){
	this.user = user;
	this.file = file;
	start();
}
public void run(){
	try{
		upload();
	}catch(Exception e){
		e.printStackTrace();
	}
}
public void upload() throws Exception {
	BasicAWSCredentials credentials = new BasicAWSCredentials("AKIAJW53TXEKCLXZWEFQ","dxpGxQ8LLOMa6BBySLZFYZWeE7vczCF7wq3AUav6");
	AmazonS3 s3Client = new AmazonS3Client(credentials);
	if(!s3Client.doesBucketExist("ldss-"+user)){
		Bucket bucket = s3Client.createBucket("ldss-"+user,"us-west-2");
	}
	s3Client.putObject("ldss-"+user,file.getName(),file);
	msg = "success";
}

}