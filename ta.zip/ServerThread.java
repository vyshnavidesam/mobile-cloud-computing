package com;
public class ServerThread extends Thread{
	TrustedAuthority server;
public ServerThread(TrustedAuthority server){
	this.server=server;
	start();
}
public void run(){
	server.start();
}
}