package com;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JTextArea;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
public class RequestHandler extends Thread{
    Socket socket;
    ObjectOutputStream out;
    ObjectInputStream in;
	JTextArea area;
public RequestHandler(Socket soc,JTextArea area){
    socket=soc;
	this.area=area;
	try{
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
	}catch(Exception e){
        e.printStackTrace();
    }
}
@Override
public void run(){
	try{
		process();		
    }catch(Exception e){
        e.printStackTrace();
    }
}
public void process()throws Exception{
	Object input[]=(Object[])in.readObject();
	String type=(String)input[0];
	if(type.equals("register")){
		String user = (String)input[1];
		SecretKey.generateKey(user);
		Object res[] = {"Secret key generated for user : "+user};
		area.append("Secret key generated for user : "+user+"\n");
		out.writeObject(res);
		out.flush();
	}
	if(type.equals("getkey")){
		String user = (String)input[1];
		FileInputStream fin = new FileInputStream("keys/"+user+"/public.txt");
		byte pub[] = new byte[fin.available()];
		fin.read(pub,0,pub.length);
		fin.close();
		
		fin = new FileInputStream("keys/"+user+"/master.txt");
		byte mas[] = new byte[fin.available()];
		fin.read(mas,0,mas.length);
		fin.close();
		
		Object res[] = {pub,mas};
		area.append("Keys sent to encryption server for user  : "+user+"\n");
		out.writeObject(res);
		out.flush();
	}
}
}
