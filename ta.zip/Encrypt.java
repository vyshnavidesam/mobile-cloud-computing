package com;
import cpabe.Cpabe;
public class Encrypt
{
public static boolean encrypt(String input,String enc,String policy,String public_key){
	boolean flag = false;
	try{
		Cpabe att = new Cpabe();
		att.enc(public_key,policy,enc,enc);
		flag = true;
	}catch(Exception e){
		e.printStackTrace();
		flag = false;
	}
	return flag;
}
}