package com;
import cpabe.Cpabe;
import java.io.File;
public class SecretKey{
public static boolean generateKey(String user){
	boolean flag = false;
	try{
		File file = new File("keys/"+user);
		if(!file.exists()){
			file.mkdir();
		}
		Cpabe att = new Cpabe();
		String public_key = "keys/"+user+"/public.txt";
		String master_key = "keys/"+user+"/master.txt";
		att.setup(public_key,master_key);
		flag = true;
	}catch(Exception e){
		e.printStackTrace();
		flag = false;
	}
	return flag;
}
public static boolean privateKey(String user,String public_key,String master_key,String private_key,String attributes){
	boolean flag = false;
	try{
		Cpabe att = new Cpabe();
		att.keygen(public_key,private_key,master_key,attributes);
		flag = true;
	}catch(Exception e){
		e.printStackTrace();
		flag = false;
	}
	return flag;
}
}